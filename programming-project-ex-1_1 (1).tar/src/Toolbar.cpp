#include "Toolbar.h"
using namespace bobcat;

void Toolbar::deselectAllTools() {
    pencilButton->color(FL_BACKGROUND_COLOR);
    eraserButton->color(FL_BACKGROUND_COLOR);
    circleButton->color(FL_BACKGROUND_COLOR);
    triangleButton->color(FL_BACKGROUND_COLOR);
    rectangleButton->color(FL_BACKGROUND_COLOR);
    polygonButton->color(FL_BACKGROUND_COLOR);
    mouseButton->color(FL_BACKGROUND_COLOR);
}

void Toolbar::visualizeSelectedTool() {
    if (tool == PENCIL) pencilButton->color(FL_WHITE);
    else if (tool == ERASER) eraserButton->color(FL_WHITE);
    else if (tool == CIRCLE) circleButton->color(FL_WHITE);
    else if (tool == TRIANGLE) triangleButton->color(FL_WHITE);
    else if (tool == RECTANGLE) rectangleButton->color(FL_WHITE);
    else if (tool == POLYGON) polygonButton->color(FL_WHITE);
    else if (tool == MOUSE) mouseButton->color(FL_WHITE);
}

void Toolbar::onClick(bobcat::Widget* sender) {
    deselectAllTools();
    action = NONE;

    if (sender == pencilButton) tool = PENCIL;
    else if (sender == eraserButton) tool = ERASER;
    else if (sender == circleButton) tool = CIRCLE;
    else if (sender == triangleButton) tool = TRIANGLE;
    else if (sender == rectangleButton) tool = RECTANGLE;
    else if (sender == polygonButton) tool = POLYGON;
    else if (sender == mouseButton) tool = MOUSE;
    else if (sender == clearButton) action = CLEAR;
    else if (sender == bringToFrontButton) action = BRING_TO_FRONT;
    else if (sender == sendToBackButton) action = SEND_TO_BACK;
    else if (sender == plusButton) action = ZOOM_IN;
    else if (sender == minusButton) action = ZOOM_OUT;

    if (onChangeCb) onChangeCb(this);
    visualizeSelectedTool();
    redraw();
}

TOOL Toolbar::getTool() const {
    return tool;
}

ACTION Toolbar::getAction() const {
    return action;
}

Toolbar::Toolbar(int x, int y, int w, int h) : Group(x, y, w, h) {
    int spacing = 50;

    pencilButton = new Image(x, y + spacing * 0, 50, 50, "./assets/pencil.png");
    eraserButton = new Image(x, y + spacing * 1, 50, 50, "./assets/eraser.png");
    circleButton = new Image(x, y + spacing * 2, 50, 50, "./assets/circle.png");
    triangleButton = new Image(x, y + spacing * 3, 50, 50, "./assets/triangle.png");
    rectangleButton = new Image(x, y + spacing * 4, 50, 50, "./assets/rectangle.png");
    polygonButton = new Image(x, y + spacing * 5, 50, 50, "./assets/polygon.png");
    clearButton = new Image(x, y + spacing * 6, 50, 50, "./assets/clear.png");
    mouseButton = new Image(x, y + spacing * 7, 50, 50, "./assets/mouse.png");
    bringToFrontButton = new Image(x, y + spacing * 8, 50, 50, "./assets/bring-to-front.png");
    sendToBackButton = new Image(x, y + spacing * 9, 50, 50, "./assets/send-to-back.png");
    plusButton = new Image(x, y + spacing * 10, 50, 50, "./assets/plus.png");
    minusButton = new Image(x, y + spacing * 11, 50, 50, "./assets/minus.png");

    tool = PENCIL;
    action = NONE;

    auto buttons = { pencilButton, eraserButton, circleButton, triangleButton,
                     rectangleButton, polygonButton, clearButton, mouseButton,
                     bringToFrontButton, sendToBackButton, plusButton, minusButton };

    for (auto* btn : buttons) {
        btn->box(FL_BORDER_BOX);
        ON_CLICK(btn, Toolbar::onClick);
    }

    visualizeSelectedTool();
}
